import { useState, useMemo, useRef, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { getMovies } from "../api/fakeapi";
import { useWatchlist } from "../context/Watchlist";
import MovieCard from "../components/MovieCard";
import Searchbox from "../components/Searchbox";
import GenreFilter from "../components/GenreFilter";

export default function Explorer() {
  const {
    data: movies = [],
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["movies"],
    queryFn: getMovies,
  });

  const { addMovie, isInWatchlist } = useWatchlist();

  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("all");
  const [showToast, setShowToast] = useState(false);

  const searchRef = useRef(null);

  const genres = ["all", "action", "comedy", "crime", "drama", "sci-fi"];

  const filteredMovies = useMemo(() => {
    return movies.filter((movie) => {
      const matchesSearch = movie.title
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

      const matchesGenre =
        selectedGenre === "all" || movie.genre === selectedGenre;

      return matchesSearch && matchesGenre;
    });
  }, [movies, searchTerm, selectedGenre]);

  const handleAdd = useCallback(
    (movie) => {
      if (!isInWatchlist(movie.id)) {
        addMovie(movie);

        setShowToast(true);

        setTimeout(() => {
          setShowToast(false);
        }, 2000);

        searchRef.current?.focus();
      }
    },
    [addMovie, isInWatchlist],
  );

  if (isLoading) {
    return <div>Loading movies...</div>;
  }

  if (isError) return <p>Failed to load movies.</p>;
  const hasNoResults = filteredMovies.length === 0;

  return (
    <div className="explorer-page">
      {showToast && <div className="toast">Movie added to watchlist.</div>}

      <Searchbox
        ref={searchRef}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search movie..."
      />

      <GenreFilter
        genres={genres}
        selectedGenre={genre}
        onSelectGenre={setGenre}
      />

      {hasNoResults ? (
        <p>No movies found.</p>
      ) : (
        <div className="movie-list">
          {filteredMovies.map((movie) => (
            <MovieCard
              key={movie.id}
              movie={movie}
              onAction={handleAdd}
              actionLabel={isInWatchlist(movie.id) ? "In Watchlist" : "Add"}
            />
          ))}
        </div>
      )}
    </div>
  );
}
